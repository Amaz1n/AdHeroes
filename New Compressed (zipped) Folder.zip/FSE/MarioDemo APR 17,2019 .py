#MarioDemo.py
from pygame import *
from math import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLACK=(0,0,0)

def moveGuy(player):
    '''moveGuy controls the location of Mario.
    It also adjusts the move and frame variables
    to ensure the correct picture is drawn
    '''
    global move,frame
    newMove=-1
    keys=key.get_pressed()
    if keys[K_RIGHT]:
        newMove=0
        player[0]+=2
        
     
    elif keys[K_DOWN]:
        newMove=1
        player[1]+=2
        
     
    elif keys[K_UP]:
        newMove=2
        player[1]-=2
        
      
    elif keys[K_LEFT]:
        newMove=3
        player[0]-=2
        
     
    else:
        frame=0 #0 is the "idle" frame (standing pose)
    print(frame)
    if move==newMove:
        frame=frame+0.2
        if frame>=len(pics[move]):
            frame=1#restarting at frame 1 (0 - standing 1-5 is walking)
    elif newMove!=-1:#this is the MOMENT we START WALKING
        move=newMove
        frame=1
        print("start")
def drawScene(screen,picList,player):
    '''
    This function is drawing only 1 of the 24 pictures
    '''
    screen.fill((200,222,244))

    print(frame)
    pic=picList[move][int(frame)]
    screen.blit(pic,(player[0],player[1]))
    display.flip()



def addPics(name,start,end):
    '''This function will return a LIST OF PICTURES
    They must be in a folder named "name" and all
    file names must start with "name".
    start,end - the range of the picture nubmers
    '''
    mypics=[]
    for i in range(start,end+1):
        mypics.append(image.load("%s/%s%03d.png"%(name,name,i)))
    return mypics



pics=[]#2d list - we will ahve 4 rows, 6 pictures in each rows
pics.append(addPics("Mario",1,6))#appending the first row (all 6 pictures for 'right')
pics.append(addPics("Mario",7,12))
pics.append(addPics("Mario",13,18))
pics.append(addPics("Mario",19,24))

mario=[200,300]
move=0 #the "row current move being performed (right,down,up,left)
frame=0 #the column" current frame within the move



myclock=time.Clock()
running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    moveGuy(mario)
    drawScene(screen,pics,mario)
    myclock.tick(60)
    
quit()
