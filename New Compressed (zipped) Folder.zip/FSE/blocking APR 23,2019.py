#blocking.py
from math import *
from pygame import *
init()
size=width,height=600,500
screen=display.set_mode(size)

maskPic=image.load("bg.png")
wallPic=image.load("wall.jpg")
guyPic=image.load("guy.png")

GREEN=(34,177,76,255)
X=0
Y=1
guy=[50,200]

def moveGuy(guy):
    keys=key.get_pressed()
    if keys[K_LEFT]:
        moveLeft(guy,10)#maximum 10 pixels
    if keys[K_RIGHT]:
        moveRight(guy,10)
    if keys[K_UP]:
        moveUp(guy,10)
    if keys[K_DOWN]:
        moveDown(guy,10)

def moveRight(guy,vx):
    for i in range(vx):
        if getPixel(maskPic,guy[X]+guyPic.get_width(),guy[Y])!=GREEN \
           and getPixel(maskPic,guy[X]+guyPic.get_width(),guy[Y]+guyPic.get_height())!=GREEN:
            guy[X]+=1

def moveLeft(guy,vx):
    for i in range(vx):
        if getPixel(maskPic,guy[X],guy[Y])!=GREEN \
           and getPixel(maskPic,guy[X],guy[Y]+guyPic.get_height())!=GREEN:
            guy[X]-=1
            
def moveUp(guy,vy):
    for i in range(vy):
        if getPixel(maskPic,guy[X]+guyPic.get_width(),guy[Y])!=GREEN \
           and getPixel(maskPic,guy[X],guy[Y])!=GREEN:
            guy[Y]-=1
            
def moveDown(guy,vy):
    for i in range(vy):
        if getPixel(maskPic,guy[X],guy[Y]+guyPic.get_height())!=GREEN \
           and getPixel(maskPic,guy[X]+guyPic.get_width(),guy[Y]+guyPic.get_height())!=GREEN:
            guy[Y]+=1
            
def drawScene(screen,guy):
    screen.blit(maskPic,(0,0))
    screen.blit(wallPic,(165,67))
    screen.blit(guyPic,(guy[X],guy[Y]))
    display.flip()
def getPixel(mask,x,y):
    if 0<=x<mask.get_width() and 0<=y<mask.get_height():
        return mask.get_at((x,y))
    return (-1,-1,-1)

                   
running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    mx,my=mouse.get_pos()
    moveGuy(guy)
    drawScene(screen,guy)
    print(getPixel(maskPic,mx,my))
quit()
