#scroll2.py
#********platforms added***********
from pygame import *
from math import *
from random import *
init()
size=width,height=500,500
screen=display.set_mode(size)

backPic=image.load("back.jpg") #4000x500
guyPic=image.load("guy.png")#29x31

X=0
Y=1
VY=2
ONGROUND=3

    #X   Y  VY ONGROUND
guy=[250,450,0,True]

plats=[Rect(randint(300,3700),randint(280,430),60,10) for i in range(40)]

def drawScene(screen,guy,plats):
    #rec=Rect(250,guy[Y],29,31)#rect for the "guy"
    offset=250-guy[X]
    screen.blit(backPic,(offset,0))
    for p in plats:
        p=p.move(offset,0)#moving left/right
        draw.rect(screen,(0,255,0),p)
    screen.blit(guyPic,(250,guy[Y]))
    #draw.rect(screen,(255,0,0),rec)
    display.flip()

def checkCollision(guy,plats):
    rec=Rect(guy[X],guy[Y],29,31)
    for p in plats:
        if rec.colliderect(p):
            if guy[VY]>0 and rec.move(0,-guy[VY]).colliderect(p)==False:#falling down
                guy[ONGROUND]=True
                guy[VY]=0
                guy[Y]=p.y-31


def moveGuy(guy):
    keys=key.get_pressed()
    if keys[K_LEFT] and guy[X]>250:
        guy[X]-=10
    if keys[K_RIGHT] and guy[X]<3500:
        guy[X]+=10
    if keys[K_SPACE] and guy[ONGROUND]:#on ground
        guy[VY]=-10
        guy[ONGROUND]=False
        
    guy[Y]+=guy[VY]
    
    guy[VY]+=0.5#applying gravity
    if guy[Y]>=450:
        guy[Y]=450#set it on ground
        guy[VY]=0#stop falling down
        guy[ONGROUND]=True
        
running=True
myClock=time.Clock()
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    moveGuy(guy)
    checkCollision(guy,plats)
    drawScene(screen,guy,plats)
    myClock.tick(60)
quit()
