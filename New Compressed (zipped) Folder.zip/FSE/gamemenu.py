# menu.py

from pygame import *
from datetime import datetime
from math import *


def simpleGame():
    SPEED=5

    rapid = 0
    bullets = []
    
    running = True
    myClock = time.Clock()
    while running:
        for evnt in event.get():          
            if evnt.type == QUIT:
                running = False

        mx, my = mouse.get_pos()
        mb = mouse.get_pressed()

        keys = key.get_pressed()
        
        if rapid>0:
            rapid-=1
        if keys[32] and rapid==0:
            rapid = 10
            #*******************************
            ang = atan2(my-300,mx-400)
            vx = cos(ang)*SPEED#horiz. component
            vy = sin(ang)*SPEED#vertical component
            #*******************************
            bullets.append([400,300,vx,vy])
            #print(bullets)

        for b in bullets[:]:
            #b[2]*=1.1
            #b[3]*=1.1
            b[0]+=b[2]
            b[1]+=b[3]
            if b[0]>800 or b[0]<0 or b[1]>600 or b[1]<0:
                bullets.remove(b)

        screen.fill((222,222,222))

        for b in bullets:
            draw.circle(screen,(255,0,0),(int(b[0]),int(b[1])), 4)

        draw.circle(screen,(0,255,0),(400,300), 20)
        myClock.tick(50)
        display.flip()
    
    return "menu"

def instructions():
    running = True
    inst = image.load("instructions.png")
    inst = transform.smoothscale(inst, screen.get_size())
    screen.blit(inst,(0,0))
    while running:
        for evnt in event.get():          
            if evnt.type == QUIT:
                running = False
        if key.get_pressed()[27]: running = False

        display.flip()
    return "menu"
        
def credit():
    running = True
    cred = image.load("credits.png")
    cred = transform.smoothscale(cred, screen.get_size())
    screen.blit(cred,(0,0))
    while running:
        for evnt in event.get():          
            if evnt.type == QUIT:
                running = False
        if key.get_pressed()[27]: running = False

        display.flip()
    return "menu"
    

def story():
    running = True
    story = image.load("story.png")
    story = transform.smoothscale(story, screen.get_size())
    screen.blit(story,(0,0))
    while running:
        for evnt in event.get():          
            if evnt.type == QUIT:
                running = False
        if key.get_pressed()[27]: running = False
        display.flip()
    return "menu"
    


def menu():
    running = True
    myClock = time.Clock()
    #buttons = [Rect(200,y*60+200,100,40) for y in range(4)]

    buttons=[Rect(200,200,100,40),Rect(200,260,100,40),
             Rect(200,320,100,40),Rect(200,380,100,40)]
    vals = ["game","instructions","credits","story"]
    while running:
        for evnt in event.get():          
            if evnt.type == QUIT:
                return "exit"

        mx,my = mouse.get_pos()
        mb = mouse.get_pressed()
        
        screen.fill((111,150,111))
        for i in range(len(buttons)):
            draw.rect(screen,(222,55,55),buttons[i])
            if buttons[i].collidepoint(mx,my):
                draw.rect(screen,(0,0,255),buttons[i],2)
                if mb[0]==1:
                    return vals[i]
            else:
                draw.rect(screen,(255,255,0),buttons[i],2)
            
           
        display.flip()

# This is the important part of the example.
# The idea is we have a variable (page) that keeps
# track of which page we are on. We give control
# of the program to a function until it is done and
# the program returns the new page it should be on.
screen = display.set_mode((800, 600))
running = True
x,y = 0,0
page = "menu"
while page != "exit":
    if page == "menu":
        page = menu()
    if page == "game":
        page = simpleGame()    
    if page == "instructions":
        page = instructions()    
    if page == "story":
        page = story()    
    if page == "credits":
        page = credit()      
quit()
