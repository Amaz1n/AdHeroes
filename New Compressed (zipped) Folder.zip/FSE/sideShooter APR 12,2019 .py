'''
Main Game Loop will always look similar to this:

while running:
    get input form the user
    move good guy (only moving!!! not drawing!!!!)
    move bad guys (only moving!!! not drawing!!!!)
    move other stuff (only moving!!! not drawing!!!)
    check interactions
    draw scene(all drawing code will be in this function)
    delay (myClock.tick(60))

'''
from pygame import *
from math import *w  
from random import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLUE=(0,0,255)
BLACK=(0,0,0) 
WHITE=(255,255,255)

MAXRAPID=13
rapid=MAXRAPID

enemies=[]
for i in range(5):
    enemies.append([randint(600,750),randint(50,550),randint(20,40)])

v=[5,0]#the horiz and vert speed of the bullet
shooter=[50,300]
        # x y horsp versp
bullets=[]

def drawScene(screen,p,bull,targ):
    screen.fill(BLACK)
    draw.circle(screen,GREEN,p,20)
    #drawing the bullets here
    for b in bull:
        draw.circle(screen,RED,(b[0],b[1]),4)
    for t in targ:
        draw.circle(screen,RED,(t[0],t[1]),40)
    display.flip()
def distance(x1,y1,x2,y2):
    return sqrt((x1-x2)**2+(y1-y2)**2)
def checkHits(bull,targ):
    for b in bull:
        for t in targ:
            if distance(b[0],b[1],t[0],t[1])<32:
                bull.remove(b)
                targ.remove(t)

def moveBullets(bull):
    for b in bull:
        b[0]+=b[2]
        b[1]+=b[3]
        if b[0]>800:
            bull.remove(b)#removing "off-screen" bullets
myclock=time.Clock()
running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    keys=key.get_pressed()
    #spacebar number is 32
    if keys[32] and rapid==MAXRAPID:
        rapid=0
        bullets.append([shooter[0]+20,shooter[1],v[0],v[1]])
    if rapid<MAXRAPID:
        rapid+=1
    mx,my=mouse.get_pos()
    shooter[1]=my
    drawScene(screen,shooter,bullets,enemies)
    moveBullets(bullets)
    checkHits(bullets,enemies)
    myclock.tick(60)
    
quit()
