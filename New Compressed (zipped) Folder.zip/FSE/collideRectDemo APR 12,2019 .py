'''
Main Game Loop will always look similar to this:

while running:
    get input form the user
    move good guy (only moving!!! not drawing!!!!)
    move bad guys (only moving!!! not drawing!!!!)
    move other stuff (only moving!!! not drawing!!!)
    check interactions
    draw scene(all drawing code will be in this function)
    delay (myClock.tick(60))

'''
from pygame import *
from math import *
from random import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLUE=(0,0,255)
BLACK=(0,0,0)
WHITE=(255,255,255)
myclock=time.Clock()

speed=2
def moveGuy(pr):
    if moveLeft and pr.left>0:
        pr.left-=speed
    if moveRight and pr.right<800:
        pr.left+=speed
    if moveUp and pr.top>0:
        pr.top-=speed
    if moveDown and pr.bottom<600:
        pr.top+=speed

def drawScene(screen,pr,targets):
    screen.fill(WHITE)
    draw.rect(screen,GREEN,pr)
    for i in range(len(targets)):
        draw.rect(screen,RED,targets[i])
    display.flip()

def checkHits(pr,targets):
    for t in targets[:]:
        if pr.colliderect(t):
            targets.remove(t)
pRect=Rect(300,200,50,50)#rect object for the player

enemies=[]
for i in range(10):
    enemies.append(Rect(randint(0,780),randint(0,580),20,20))


moveLeft=False
moveRight=False
moveUp=False
moveDown=False

myclock=time.Clock()
running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
        if evt.type==KEYDOWN:
            if evt.key==K_a:
                moveLeft=True
            if evt.key==K_d:
                moveRight=True
            if evt.key==K_s:
                moveDown=True
            if evt.key==K_w:
                moveUp=True
        if evt.type==KEYUP:
            if evt.key==K_a:
                moveLeft=False
            if evt.key==K_d:
                moveRight=False
            if evt.key==K_s:
                moveDown=False
            if evt.key==K_w:
                moveUp=False

    moveGuy(pRect)
    checkHits(pRect,enemies)
    drawScene(screen,pRect,enemies)

    
quit()
