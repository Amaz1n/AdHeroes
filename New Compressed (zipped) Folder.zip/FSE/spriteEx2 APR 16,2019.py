#spriteEx1.py
'''
The first example has the animation display
too quickly. We can slow it down by lowering
the frame rate, but that will slow down
the WHOLE GAME. A better choice is to
NOT ADVANCE our frame each time around the
"while running" loop
'''


from pygame import *
from pygame import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLACK=(0,0,0)
WHITE=(255,255,255)
myclock=time.Clock()


frame=0
pics=[]
for i in range(9):
    pics.append(image.load("ryu\\ryu"+str(i)+".png"))




running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    screen.fill((100,200,100))
    screen.blit(pics[int(frame)],(100,100))
    frame+=0.1
    frame=frame%9
    display.flip()                   
    myclock.tick(60)

quit()
