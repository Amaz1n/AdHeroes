from pygame import *
from math import *
    
screen = display.set_mode((800,600))

running=True

X=0
Y=1
VX=2
VY=3

     #x   y  vx vy
ball=[100,200,5,2]
myclock=time.Clock()
while running:
    for evt in event.get():
        if evt.type == QUIT:
            running = False

    #ball[VY] += .3 #gravity
    ball[X] += ball[VX]
    ball[Y] += ball[VY]

    if ball[X]<0 or ball[X]>800:
        ball[VX] *= -1 #change direction (hor)
    if ball[Y]<0 or ball[Y]>600: 
        ball[VY] *= -1 #change direction (ver)
    
    screen.fill((0,0,0))

    draw.circle(screen,(255,0,0),(int(ball[X]),int(ball[Y])),10)
    
    display.flip()
    myclock.tick(60)

quit()
