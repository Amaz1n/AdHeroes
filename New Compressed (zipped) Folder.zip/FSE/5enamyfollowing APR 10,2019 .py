'''
Main Game Loop will always look similar to this:

while running:
    get input form the user
    move good guy (only moving!!! not drawing!!!!)
    move bad guys (only moving!!! not drawing!!!!)
    move other stuff (only moving!!! not drawing!!!)
    check interactions
    draw scene(all drawing code will be in this function)
    delay (myClock.tick(60))

'''


from pygame import *
from math import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLUE=(0,0,255)
BLACK=(0,0,0)
WHITE=(255,255,255)


enemies=[[0,20],[100,20],[200,20],[300,20],[400,20],[500,20],[600,20]]

def drawScene(screen,badGuys,goodX,goodY):
    #1. draw backgroud
    '''Each bad guy is a red circle, the good guy
    is a green circle
    '''
    screen.fill(BLACK)
    for guy in badGuys:
        draw.circle(screen,RED,guy,20)
    draw.circle(screen,GREEN,(goodX,goodY),20)#player
    display.flip()
def moveBadGuys(badGuys,goodX,goodY):
    for guy in badGuys:
        if goodX>guy[0]:
            guy[0]+=1
        if goodX<guy[0]:
            guy[0]-=1
        if goodY>guy[1]:
            guy[1]+=1
        if goodY<guy[1]:
            guy[1]-=1
def checkHit(badGuys,goodX,goodY):
    for i in range(len(badGuys)):
        d=sqrt((goodX-badGuys[i][0])**2+(goodY-badGuys[i][1])**2)
        if d<40:
            badGuys[i][0]=i*100
            badGuys[i][1]=20

myclock=time.Clock()
    
running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    mb=mouse.get_pressed()
    mx,my=mouse.get_pos()
    moveBadGuys(enemies,mx,my)
    checkHit(enemies,mx,my)
    drawScene(screen,enemies,mx,my)
    myclock.tick(60)

quit()
