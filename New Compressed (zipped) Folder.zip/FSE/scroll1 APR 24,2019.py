#scrolll.py
#simple example of a scrolling background.
#The program uses just one picture (4000x500)
#We are drawing the background at a negative position
from pygame import *
from math import *
init()
size=width,height=500,500
screen=display.set_mode(size)

backPic=image.load("back.jpg") #4000x500
guyPic=image.load("guy.png")#29x31

X=0
Y=1
VY=2
    #X  Y  VY
guy=[0,450,0]

def drawScene(screen,guy):
    screen.blit(backPic,(-guy[X],0))
    screen.blit(guyPic,(250,guy[Y]))
    display.flip()

def moveGuy(guy):
    keys=key.get_pressed()
    if keys[K_LEFT] and guy[X]>0:
        guy[X]-=10
    if keys[K_RIGHT] and guy[X]<3500:
        guy[X]+=10
    if keys[K_SPACE] and guy[Y]==450:#on ground
        guy[VY]=-5
        
    guy[Y]+=guy[VY]
    
    guy[VY]+=0.1#applying gravity
    if guy[Y]>=450:
        guy[Y]=450#set it on ground
        guy[VY]=0#stop falling down
    
running=True
myClock=time.Clock()
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    drawScene(screen,guy)
    moveGuy(guy)
    myClock.tick(60)
quit()
