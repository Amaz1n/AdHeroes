from pygame import *
from math import *
from random import *
font.init()
courierFont=font.SysFont("Courier New",25)
init()
size=width,height=1024,800
screen=display.set_mode(size)

back2=image.load("roboYardBack.png")

running=True
while running:
    for evnt in event.get():
        if evnt.type==QUIT:
            running=False
    mx,my=mouse.get_pos()
    mb=mouse.get_pressed()
    screen.blit(back2,(0,0))
    draw.rect(screen,(0,0,255),(150,190,200,40))
    draw.rect(screen,(0,0,255),(700,190,200,40))
    draw.rect(screen,(0,0,255),(140,420,300,40))
    draw.rect(screen,(0,0,255),(570,420,300,40))
    draw.rect(screen,(0,0,255),(0,550,1024,40))
    display.flip()
quit()
