'''
Main Game Loop will always look similar to this:

while running:
    get input form the user
    move good guy (only moving!!! not drawing!!!!)
    move bad guys (only moving!!! not drawing!!!!)
    move other stuff (only moving!!! not drawing!!!)
    check interactions
    draw scene(all drawing code will be in this function)
    delay (myClock.tick(60))

'''




from pygame import *
from math import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLUE=(0,0,255)
BLACK=(0,0,0)
WHITE=(255,255,255)


ex=20#enemy's coordinates
ey=20


running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    screen.fill(BLACK)
    mb=mouse.get_pressed()
    mx,my=mouse.get_pos()

    d=sqrt((mx-ex)**2+(my-ey)**2)
    #distance between the centers of the circles
    #print(d)
    if mx>ex:
        ex+=1
    if mx<ex:
        ex-=1
    if my>ey:
        ey+=1
    if my<ey:
        ey-=1
    if d<40:
        ex=20
        ey=20
    draw.circle(screen,GREEN,(mx,my),20)#player
    draw.circle(screen,RED,(ex,ey),20)#enemy
    display.flip() 

quit()
