#spriteEx1.py
from pygame import *
from pygame import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLACK=(0,0,0)
WHITE=(255,255,255)
myclock=time.Clock()


frame=0
pics=[]
for i in range(9):
    pics.append(image.load("ryu\\ryu"+str(i)+".png"))




running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    screen.fill((100,200,100))
    screen.blit(pics[frame],(100,100))
    frame+=1
    frame=frame%9
    display.flip()                   
    myclock.tick(6)

quit()
