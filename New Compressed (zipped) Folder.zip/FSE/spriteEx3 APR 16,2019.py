#spriteEx1.py
'''

'''


from pygame import *
from random import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLACK=(0,0,0)
WHITE=(255,255,255)
myclock=time.Clock()
px,py=100,100
counter=0#this will be used to count the frames

frame=0
frameDelay=6
pics=[]
for i in range(9):
    pics.append(image.load("ryu\\ryu"+str(i)+".png"))




running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
    counter+=1
    if counter%120==0:
        px=randint(50,750)
        py=randint(50,550)
    screen.fill((100,200,100))

    screen.blit(pics[int(frame)],(px,py))
    frameDelay-=1
    if frameDelay==0:
        frameDelay=6
        frame+=1
        frame=frame%9
   
    display.flip()                   
    myclock.tick(60)

quit()
