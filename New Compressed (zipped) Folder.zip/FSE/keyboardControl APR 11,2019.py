'''
Main Game Loop will always look similar to this:

while running:
    get input form the user
    move good guy (only moving!!! not drawing!!!!)
    move bad guys (only moving!!! not drawing!!!!)
    move other stuff (only moving!!! not drawing!!!)
    check interactions
    draw scene(all drawing code will be in this function)
    delay (myClock.tick(60))

'''




from pygame import *
from math import *
size=width,height=800,600
screen=display.set_mode(size)
RED=(255,0,0)   
GREEN=(0,255,0)
BLUE=(0,0,255)
BLACK=(0,0,0)
WHITE=(255,255,255)

        #x y vx vy
player=[650,50,0,0]

def drawScene(screen,p):
    screen.fill(BLACK)
    draw.circle(screen,GREEN,(p[0],p[1]),20)
    display.flip() 

def movePlayer(p):
    p[0]+=p[2]
    p[1]+=p[3]
    if p[0]<0:
        p[0]=0
    if p[0]>width:
        p[0]=width
    if p[1]<0:
        p[1]=0
    if p[1]>height:
        p[1]=height

myclock=time.Clock()
running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
        elif evt.type==KEYDOWN:
            if evt.key==K_LEFT:
                player[2]=-5
            if evt.key==K_RIGHT:
                player[2]=5
            if evt.key==K_UP:
                player[3]=-5
            if evt.key==K_DOWN:
                player[3]=5
        elif evt.type==KEYUP:
            if evt.key==K_LEFT or evt.key==K_RIGHT:
                player[2]=0
            if evt.key==K_DOWN or evt.key==K_UP:
                player[3]=0
    movePlayer(player)     
    drawScene(screen,player)
    
    myclock.tick(60)
quit()
