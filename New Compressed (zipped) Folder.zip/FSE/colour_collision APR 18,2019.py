
from pygame import *
import os
os.environ['SKL_VIDEO_WINDOW_POS'] = "250,150"

init()
screen=display.set_mode((450,400))
#maze=image.load("maze.bmp")
maze=image.load("maze.jpg")

wallC=maze.get_at((0,0))
  #x  y  r
b=[32,15,4]
s=[2,2]
def drawScene():
    screen.blit(maze,(0,0))
    draw.circle(screen,(255,0,0),(b[0],b[1]),b[2])
    display.flip()

myClock=time.Clock()
running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False

    keys=key.get_pressed()
    if keys[K_LEFT]:
        b[0]-=s[0]
    if keys[K_RIGHT]:
        b[0]+=s[0]
    if keys[K_UP]:
        b[1]-=s[1]
    if keys[K_DOWN]:
        b[1]+=s[1]
              #right                left
    points=[(b[0]+b[2]+1,b[1]),(b[0]-b[2]-1,b[1]),
            (b[0],b[1]+b[2]+1),(b[0],b[1]-b[2]-1)]
                 #down              up       

    for p in points:
        if screen.get_at(p)==wallC:
            b[0]=32
            b[1]=15
            
    drawScene()

    if b[0]>388:
        print("You win")
        running=False
        
    #print(screen.get_at((b[0]+b[2]+1,b[1])))
  
    myClock.tick(50)

quit()
